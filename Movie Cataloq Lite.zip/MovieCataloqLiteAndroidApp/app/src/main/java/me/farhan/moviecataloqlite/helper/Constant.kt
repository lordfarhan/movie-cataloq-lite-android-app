package me.farhan.moviecataloqlite.helper

/**
 * @author farhan
 * created at at 9:33 on 03/03/21.
 */
const val SPLASH_SCREEN_TIMEOUT = 1500L